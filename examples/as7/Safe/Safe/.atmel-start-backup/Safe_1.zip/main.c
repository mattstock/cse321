#include <atmel_start.h>

int main(void)
{
	struct io_descriptor *I2C_0_io;
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	i2c_m_sync_get_io_descriptor(&I2C_0, &I2C_0_io);
	i2c_m_sync_enable(&I2C_0);
	i2c_m_sync_set_slaveaddr(&I2C_0, 0x72, I2C_M_SEVEN);
	io_write(I2C_0_io, "|-", 5);
	
	/* Replace with your application code */
	while (1) {
		gpio_set_pin_direction(K_ROW0, GPIO_DIRECTION_OUT);
		if (!gpio_get_pin_level(K_COL0))
			io_write(I2C_0_io, "00", 2);
		if (!gpio_get_pin_level(K_COL1))
			io_write(I2C_0_io, "01", 2);
		if (!gpio_get_pin_level(K_COL2))
			io_write(I2C_0_io, "02", 2);
		if (!gpio_get_pin_level(K_COL3))
			io_write(I2C_0_io, "03", 2);
		delay_ms(2000);
		gpio_set_pin_level(LED0, gpio_get_pin_level(SW0));
	}
}
